create function riordina_frame() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Riduci l'ordine dei frame successivi a quello eliminato
    UPDATE frame
    SET ordine = ordine - 1
    WHERE id_video = OLD.id_video AND ordine > OLD.ordine;

    RETURN NULL; -- il valore di ritorno non è rilevante per un trigger AFTER DELETE
END;
$$;

alter function riordina_frame() owner to postgres;

