create function save_tagphoto() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE fotografia
    SET username_autore = NULL
    WHERE username_autore= OLD.username AND condivisa = TRUE AND EXISTS (
        SELECT * FROM tag_utente
        WHERE tag_utente.id_foto = fotografia.id_foto AND tag_utente.username<>fotografia.username_autore
    );
    RETURN OLD;
END;
$$;

alter function save_tagphoto() owner to postgres;

