create function generate_frame_order() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.ordine := (SELECT COALESCE(MAX(ordine), 0) FROM frame WHERE id_video = NEW.id_video) + 1;
    RETURN NEW;
END;
$$;

alter function generate_frame_order() owner to postgres;

