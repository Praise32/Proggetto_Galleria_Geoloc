create view categoriasoggetto(categoria) as
SELECT DISTINCT soggetto.categoria
FROM soggetto;

alter table categoriasoggetto
    owner to postgres;

