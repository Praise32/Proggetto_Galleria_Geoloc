create function foto_per_tag_utente(in_username character varying) returns SETOF fotografia
    language plpgsql
as
$$
BEGIN
    RETURN QUERY (
        SELECT fotografia.*
        FROM fotografia
                 JOIN tag_utente ON tag_utente.id_foto = fotografia.id_foto
        WHERE tag_utente.username = in_username
    );
END;
$$;

alter function foto_per_tag_utente(varchar) owner to postgres;

