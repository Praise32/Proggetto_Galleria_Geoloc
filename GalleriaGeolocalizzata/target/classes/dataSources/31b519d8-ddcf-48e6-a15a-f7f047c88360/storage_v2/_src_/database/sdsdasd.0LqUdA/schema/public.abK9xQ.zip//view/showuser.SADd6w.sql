create view showuser(username) as
SELECT DISTINCT utente.username
FROM utente;

alter table showuser
    owner to postgres;

