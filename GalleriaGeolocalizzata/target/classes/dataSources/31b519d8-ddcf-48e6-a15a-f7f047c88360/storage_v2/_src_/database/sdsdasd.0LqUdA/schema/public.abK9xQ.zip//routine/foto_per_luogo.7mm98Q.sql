create function foto_per_luogo(in_nome character varying, utente character varying) returns SETOF fotografia
    language plpgsql
as
$$
BEGIN
    RETURN QUERY (
        SELECT fotografia.*
        FROM fotografia
                 JOIN luogo ON fotografia.latitudine = luogo.latitudine AND fotografia.longitudine = luogo.longitudine
        WHERE luogo.nome = in_nome AND (
                    fotografia.username_autore = utente OR fotografia.condivisa = TRUE
            )
    );
END;
$$;

alter function foto_per_luogo(varchar, varchar) owner to postgres;

