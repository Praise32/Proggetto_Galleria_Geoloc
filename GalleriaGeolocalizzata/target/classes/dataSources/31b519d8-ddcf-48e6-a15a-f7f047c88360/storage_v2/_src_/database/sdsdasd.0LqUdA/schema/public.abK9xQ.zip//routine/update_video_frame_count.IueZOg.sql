create function update_video_frame_count() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'INSERT') THEN
        UPDATE video SET numero_frames = numero_frames + 1 WHERE id_video = NEW.id_video;
    ELSIF (TG_OP = 'DELETE') THEN
        UPDATE video SET numero_frames = numero_frames - 1 WHERE id_video = OLD.id_video;
    END IF;
    RETURN NULL;
END;
$$;

alter function update_video_frame_count() owner to postgres;

