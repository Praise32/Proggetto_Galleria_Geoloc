create function rimuovi_foto_privata() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM frame WHERE id_foto = OLD.id_foto;
    RETURN NEW;
END;
$$;

alter function rimuovi_foto_privata() owner to postgres;

