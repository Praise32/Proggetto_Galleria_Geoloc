create function aggiorna_elementi_galleria() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'INSERT') THEN
        UPDATE collezione SET numero_elementi = numero_elementi + 1 WHERE id_collezione = NEW.id_collezione;
    ELSIF (TG_OP = 'DELETE') THEN
        UPDATE collezione SET numero_elementi = numero_elementi - 1 WHERE id_collezione = OLD.id_collezione;
    END IF;
    RETURN NULL;
END;
$$;

alter function aggiorna_elementi_galleria() owner to postgres;

