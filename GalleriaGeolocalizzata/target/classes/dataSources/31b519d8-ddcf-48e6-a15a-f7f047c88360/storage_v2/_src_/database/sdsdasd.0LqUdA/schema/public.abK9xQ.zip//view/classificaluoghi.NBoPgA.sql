create view classificaluoghi(latitudine, longitudine, nome, descrizione, numerofotografie) as
SELECT luogo.latitudine,
       luogo.longitudine,
       luogo.nome,
       luogo.descrizione,
       count(fotografia.id_foto) AS numerofotografie
FROM luogo
         LEFT JOIN fotografia USING (latitudine, longitudine)
GROUP BY luogo.latitudine, luogo.longitudine, luogo.nome, luogo.descrizione
ORDER BY (count(fotografia.id_foto)) DESC, luogo.nome
LIMIT 3;

alter table classificaluoghi
    owner to postgres;

