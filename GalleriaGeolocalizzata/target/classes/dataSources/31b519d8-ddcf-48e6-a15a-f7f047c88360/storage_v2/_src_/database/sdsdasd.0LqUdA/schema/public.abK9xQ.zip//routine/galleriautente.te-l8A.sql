create function galleriautente(utente character varying, richiedente character varying) returns SETOF fotografia
    language plpgsql
as
$$
BEGIN
    RETURN QUERY (
        SELECT * FROM fotografia
        WHERE fotografia.username_autore = Utente AND (
                    fotografia.username_autore = Richiedente OR fotografia.condivisa = TRUE
            )
    );
END;
$$;

alter function galleriautente(varchar, varchar) owner to postgres;

