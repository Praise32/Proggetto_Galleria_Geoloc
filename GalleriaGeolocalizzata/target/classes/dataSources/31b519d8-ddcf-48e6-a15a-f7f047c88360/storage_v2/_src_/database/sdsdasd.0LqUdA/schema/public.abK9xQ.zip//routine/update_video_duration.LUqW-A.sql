create function update_video_duration() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE video
    SET durata = (
        SELECT SUM(durata)
        FROM frame
        WHERE id_video = NEW.id_video
    )
    WHERE id_video = NEW.id_video;
    RETURN NEW;
END;
$$;

alter function update_video_duration() owner to postgres;

