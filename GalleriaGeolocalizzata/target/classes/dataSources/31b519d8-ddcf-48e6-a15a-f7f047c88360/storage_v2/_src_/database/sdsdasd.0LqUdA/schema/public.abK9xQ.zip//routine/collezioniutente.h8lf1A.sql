create function collezioniutente(utente character varying) returns SETOF collezione
    language plpgsql
as
$$
BEGIN
    RETURN QUERY (
        SELECT * FROM collezione
        WHERE collezione.username = utente
    );
END;
$$;

alter function collezioniutente(varchar) owner to postgres;

