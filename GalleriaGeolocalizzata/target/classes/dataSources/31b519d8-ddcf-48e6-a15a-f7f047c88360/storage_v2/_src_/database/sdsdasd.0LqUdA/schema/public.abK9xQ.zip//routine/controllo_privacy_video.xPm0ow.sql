create function controllo_privacy_video() returns trigger
    language plpgsql
as
$$
DECLARE
    proprietario_foto VARCHAR;
    proprietario_video VARCHAR;
BEGIN
    IF (SELECT condivisa FROM fotografia WHERE NEW.id_foto = fotografia.id_foto) = false THEN
        RAISE EXCEPTION 'Non è possibile utilizzare foto private per video.';
    END IF;
    RETURN NEW;
END;
$$;

alter function controllo_privacy_video() owner to postgres;

