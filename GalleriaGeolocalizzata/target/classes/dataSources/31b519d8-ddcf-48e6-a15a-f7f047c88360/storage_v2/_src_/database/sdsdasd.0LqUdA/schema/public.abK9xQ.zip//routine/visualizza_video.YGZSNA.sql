create function visualizza_video(in_titolo character varying) returns SETOF frame
    language plpgsql
as
$$
BEGIN
    RETURN QUERY (
        SELECT frame.*
        FROM frame
                 JOIN video ON video.id_video = frame.id_video
        WHERE video.titolo = in_titolo
        ORDER BY ordine
    );
END;
$$;

alter function visualizza_video(varchar) owner to postgres;

