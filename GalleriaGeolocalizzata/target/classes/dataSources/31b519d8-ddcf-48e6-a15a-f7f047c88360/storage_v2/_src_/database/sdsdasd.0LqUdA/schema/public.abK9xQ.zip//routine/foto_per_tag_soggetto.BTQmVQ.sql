create function foto_per_tag_soggetto(in_nome_soggetto character varying, utente_richiedente character varying) returns SETOF fotografia
    language plpgsql
as
$$
BEGIN
    RETURN QUERY (
        SELECT fotografia.*
        FROM fotografia
                 JOIN tag_soggetto ON tag_soggetto.id_foto = fotografia.id_foto
        WHERE tag_soggetto.nome_soggetto = in_nome_soggetto AND (
                    fotografia.username_autore= utente_richiedente OR fotografia.condivisa = TRUE)
    );
END;
$$;

alter function foto_per_tag_soggetto(varchar, varchar) owner to postgres;

