create function controllo_autore() returns trigger
    language plpgsql
as
$$
DECLARE
    proprietario_foto VARCHAR;
    proprietario_collezione VARCHAR;
BEGIN
    SELECT username_autore INTO proprietario_foto FROM fotografia WHERE id_foto=NEW.id_foto;
    SELECT username INTO proprietario_collezione FROM collezione WHERE id_collezione=NEW.id_collezione;
    IF NOT EXISTS (SELECT * FROM fotografia WHERE id_foto = NEW.id_foto AND ((condivisa = true) OR (proprietario_foto = proprietario_collezione))) THEN
        RAISE EXCEPTION 'Non sei autorizzato ad utilizzare questa foto';
    END IF;
    RETURN NEW;
END;
$$;

alter function controllo_autore() owner to postgres;

