create function check_and_delete_photo() returns trigger
    language plpgsql
as
$$
DECLARE
    count_collection INTEGER;
    count_frame INTEGER;
BEGIN
    -- Verifica se la fotografia è presente in una collezione
    SELECT COUNT(*) INTO count_collection
    FROM contenuto
    WHERE id_foto = OLD.id_foto;
    
    -- Verifica se la fotografia è presente in un video
    SELECT COUNT(*) INTO count_frame
    FROM frame
    WHERE id_foto = OLD.id_foto;
    
    -- Se la fotografia non è presente in nessuna collezione o video, la elimina
    IF ((SELECT username_autore FROM fotografia WHERE id_foto = OLD.id_foto) IS NULL AND count_collection = 0 AND count_frame = 0) THEN
        DELETE FROM fotografia WHERE id_foto = OLD.id_foto;
    END IF;

    RETURN OLD;
END;
$$;

alter function check_and_delete_photo() owner to postgres;

