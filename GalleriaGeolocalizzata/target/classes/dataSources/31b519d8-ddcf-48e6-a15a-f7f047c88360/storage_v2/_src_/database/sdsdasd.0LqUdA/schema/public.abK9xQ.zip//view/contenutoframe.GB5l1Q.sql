create view contenutoframe(dati_foto, id_video, id_foto, durata, ordine) as
SELECT fotografia.dati_foto,
       frame.id_video,
       frame.id_foto,
       frame.durata,
       frame.ordine
FROM fotografia
         JOIN frame ON fotografia.id_foto = frame.id_foto;

alter table contenutoframe
    owner to postgres;

