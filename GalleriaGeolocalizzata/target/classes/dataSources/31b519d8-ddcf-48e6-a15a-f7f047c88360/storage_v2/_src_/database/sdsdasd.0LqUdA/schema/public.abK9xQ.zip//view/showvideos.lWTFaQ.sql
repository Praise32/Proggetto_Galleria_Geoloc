create view showvideos("Titolo", "Autore", "Info") as
SELECT video.titolo      AS "Titolo",
       video.autore      AS "Autore",
       video.descrizione AS "Info"
FROM video;

alter table showvideos
    owner to postgres;

