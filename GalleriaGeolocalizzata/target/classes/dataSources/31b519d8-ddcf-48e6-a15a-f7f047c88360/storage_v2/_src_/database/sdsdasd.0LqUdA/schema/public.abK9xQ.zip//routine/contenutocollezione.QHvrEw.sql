create function contenutocollezione(collezione integer) returns SETOF fotografia
    language plpgsql
as
$$
BEGIN
    RETURN QUERY(
        SELECT fotografia.*
        FROM contenuto NATURAL JOIN fotografia
        WHERE id_collezione = collezione
    );
END;
$$;

alter function contenutocollezione(integer) owner to postgres;

