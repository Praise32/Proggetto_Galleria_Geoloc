create view showadmin(username, admin) as
SELECT DISTINCT utente.username,
                utente.admin
FROM utente
WHERE utente.admin = true;

alter table showadmin
    owner to postgres;

